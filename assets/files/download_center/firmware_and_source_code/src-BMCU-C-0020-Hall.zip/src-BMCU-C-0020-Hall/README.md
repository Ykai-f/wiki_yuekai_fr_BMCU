# BMCU 自定义固件

## 简介
此固件用于对 BMCU 进行自定义修改，包括电机方向、退料距离、耗材颜色显示等设置。

---

## 文件说明

### 电机相关配置  
请查看 **`src\Motion_control.cpp`**:
- 退料距离修改（仅 P1 和 X1 生效）  
  - 第 31 行
- 禁止触发双微动辅助进料  
  - 第 35 行
- 禁用通道耗材丝颜色的显示  
  - 第 686-688 行
- 指定通道电机方向 / 禁用自动方向检测  
  - 第 994-999 行

### 协议相关配置  
请查看 **`src\BambuBus.cpp`**:
- 修改被识别的设备名 A/B/C/D（适用于 X1/P1）  
  - 第 10 行

---

## 使用说明
1. 克隆本仓库  
2. 根据需求修改对应文件  
3. 编译并刷入固件

---

## 注意事项
- 修改固件存在风险，请确保了解操作步骤  
- 建议备份原始固件以防回退

---

# BMCU Custom Firmware

## Introduction
This firmware allows customization of BMCU, including motor direction, retraction distance, filament color display, and more.

---

## File References

### Motor-related Configurations  
Refer to **`src\Motion_control.cpp`**:
- Modify retraction distance (effective only on P1 and X1)  
  - Line 31
- Disable dual micro-switch assisted feeding  
  - Line 35
- Disable filament color display for channels  
  - Lines 686-688
- Specify channel motor direction / disable auto direction detection  
  - Lines 994-999

### Protocol-related Configurations  
Refer to **`src\BambuBus.cpp`**:
- Modify recognized device names A/B/C/D (for X1/P1)  
  - Line 10

---

## Usage
1. Clone this repository  
2. Modify the relevant files as needed  
3. Compile and flash the firmware

---

## Notes
- Firmware modification carries risks. Proceed only if you understand the process.  
- It is recommended to back up the original firmware.
