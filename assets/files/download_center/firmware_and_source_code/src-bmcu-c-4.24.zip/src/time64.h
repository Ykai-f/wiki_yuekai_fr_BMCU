
#pragma once
#include "main.h"

extern uint64_t get_time64();
