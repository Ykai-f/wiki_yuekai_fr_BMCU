#pragma once
#include "main.h"


extern void ADC_DMA_init();
extern float *ADC_DMA_get_value();